# opossum examples

This repository contains a few examples for the https://github.com/nodeshift/opossum circuit breaker.
